//! Probe: thin SVD cost at n = 32..128 against `SvdParams::recursion_threshold`.
//!
//! Not evidence: this is the decision probe that says whether the threshold is the
//! phase that carries the loss. The adoption measurement goes through fbench.
use faer::dyn_stack::{MemBuffer, MemStack};
use faer::linalg::svd::{svd, svd_scratch, ComputeSvdVectors, SvdParams};
use faer::prelude::*;
use faer::{Auto, Par, Spec};
use std::time::Instant;

fn make(n: usize, seed: u64) -> Mat<f64> {
    let mut a = Mat::<f64>::zeros(n, n);
    let mut s = seed | 1;
    for j in 0..n {
        for i in 0..n {
            s = s
                .wrapping_mul(6364136223846793005)
                .wrapping_add(1442695040888963407);
            a[(i, j)] = ((s >> 11) as f64 / (1u64 << 53) as f64) - 0.5;
        }
    }
    a
}

/// one timed call at (n, threads, threshold); returns ms
fn time_cell(a: &Mat<f64>, n: usize, threads: usize, thr: usize) -> f64 {
    let mut s = Mat::<f64>::zeros(n, n);
    let mut u = Mat::<f64>::zeros(n, n);
    let mut v = Mat::<f64>::zeros(n, n);
    let params = Spec::new(SvdParams {
        recursion_threshold: thr,
        ..Auto::<f64>::auto()
    });
    let mut run = |par: Par<'_>| {
        let mut memory = MemBuffer::new(svd_scratch::<f64>(
            n,
            n,
            ComputeSvdVectors::Thin,
            ComputeSvdVectors::Thin,
            par.shape(),
            params,
        ));
        let mut stack = MemStack::new(&mut memory);
        svd(
            a.as_ref(),
            s.as_mut().diagonal_mut(),
            Some(u.as_mut()),
            Some(v.as_mut()),
            par,
            &mut stack,
            params,
        )
        .unwrap();
    };
    let t = Instant::now();
    if threads == 1 {
        run(Par::Seq);
    } else {
        faer::team::with_team(threads, run);
    }
    t.elapsed().as_secs_f64() * 1e3
}

fn main() {
    let args: Vec<String> = std::env::args().collect();
    let reps: usize = args.get(1).map(|s| s.parse().unwrap()).unwrap_or(5);
    let warm: usize = args.get(2).map(|s| s.parse().unwrap()).unwrap_or(3);
    let ns: Vec<usize> = args.get(3).map(|s| s.split(',').map(|x| x.parse().unwrap()).collect())
        .unwrap_or(vec![32, 64, 96, 128]);
    let thrs: Vec<usize> = args.get(4).map(|s| s.split(',').map(|x| x.parse().unwrap()).collect())
        .unwrap_or(vec![128, 96, 64, 32]);
    println!("n,threads,threshold,ms");
    for &n in &ns {
        let a = make(n, 12345 + n as u64);
        for &t in &[1usize, 4, 8] {
            for &thr in &thrs {
                for _ in 0..warm {
                    time_cell(&a, n, t, thr);
                }
                let mut best = f64::INFINITY;
                for _ in 0..reps {
                    best = best.min(time_cell(&a, n, t, thr));
                }
                println!("{n},{t},{thr},{best:.4}");
            }
        }
    }
}
