# The decision probe behind the value 40

Not acceptance evidence. The campaign pair in the two run directories beside this one is the
acceptance measurement; this probe answered only "is the threshold the phase that carries the loss,
and where is its floor" before a campaign was spent on it.

Driver: `src/main.rs`, a single binary against the fork at `4d140a9` (`Cargo.toml` points at a local
checkout; build with `cargo build --release` and point the path dependency at the fork).

Each run is one invocation over the fork's `svd` with `SvdParams { recursion_threshold }` overridden
per call: `svdprobe <reps> <warm> <n,...> <threshold,...>`, warm-up calls first, then `reps` timed
calls, and it prints the **minimum** of those. Pinned to cores 4-11 under the campaign's guard
(`pinned.sh`, 3 s idle window, 5% busy, 8 retries); the `.guard` file next to each CSV is that
guard's own output and says the cores were idle before and after.

| file | shapes | thresholds |
|---|---|---|
| `probe1.csv` | 32, 64, 96, 128 | 32, 64, 96, 128 |
| `probe2.csv` | 32, 64, 96, 128, 256, 512 | 33, 40, 48, 56, 64, 128 |
| `probe3.csv` | 32, 64, 96, 128 | 33, 36, 40, 44, 48, 64, 128 |
| `probe4.csv` | 512, 1024 | 40, 48, 64, 128 |

Columns: `n, threads, threshold, ms`. Threads are 1, 4 and 8 in every file. The same
(n, threads, threshold) appears more than once across the four files, because the later passes
re-ran cells from the earlier ones; the number used is the minimum over every committed row, which
is the statistic the worklog's Table C and its reproduction script both use.

What it said (worklog Table C): at n = 96 the cost is flat from 33 to 44 and 4.7% (1T) / 9.8% (8T)
worse at 48; at n = 32 the recursion costs 11% at 1T, so the guard cell must stay on QR; and at
n = 1024, 8T the two are equal (167.043 vs 167.040 ms), so the gate does not matter there.
