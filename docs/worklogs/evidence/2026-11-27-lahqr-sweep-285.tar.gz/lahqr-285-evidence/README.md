# colmat-rs#285 evidence

`src/main.rs` + `Cargo.toml` + `build.rs`: the probe (path dependency `colmat` -> edit the path to your checkout; links system `-lopenblas`).
Run: `OPENBLAS_NUM_THREADS=1 taskset -c 2 ./target/release/schur-probe 301` (timing table), `HASH=1 ./schur-probe` (bit hash of T, Z, wr, wi),
`ONLY_N=64 LOOPS=20 valgrind --tool=callgrind ./schur-probe` / `ONLY_OB=64 ...` (instruction counts, colmat / OpenBLAS dhseqr).
`before.N` / `after.N`: three timing runs each (301 calls, median). `hash.before` == `hash.after`.
Host: AMD RYZEN AI MAX+ 395, boost on, system OpenBLAS 0.3.26 (openblas-pthread).
