use colmat::dyn_stack::{MemBuffer, MemStack, StackReq};
use colmat::linalg::evd::*;
use colmat::linalg::householder::*;
use colmat::linalg::qr::no_pivoting::factor::recommended_block_size;
use colmat::{Col, Mat, Par};
use std::time::Instant;

extern "C" {
    fn dhseqr_(job:*const u8,compz:*const u8,n:*const i32,ilo:*const i32,ihi:*const i32,h:*mut f64,ldh:*const i32,wr:*mut f64,wi:*mut f64,z:*mut f64,ldz:*const i32,work:*mut f64,lwork:*const i32,info:*mut i32);
}

fn hess(n: usize, seed: u64) -> Mat<f64> {
    let mut state = seed;
    let mut next = || { state ^= state << 13; state ^= state >> 7; state ^= state << 17; (state >> 11) as f64 / (1u64 << 53) as f64 * 2.0 - 1.0 };
    let mut a = Mat::<f64>::from_fn(n, n, |_, _| next());
    let bs = recommended_block_size::<f64>(n - 1, n - 1);
    let mut coeff = Mat::<f64>::zeros(bs, n - 1);
    let mut mem = MemBuffer::new(StackReq::any_of(&[
        hessenberg::hessenberg_in_place_scratch::<f64>(n, bs, Par::Seq.shape(), Default::default()),
        apply_block_householder_sequence_on_the_right_in_place_scratch::<f64>(n - 1, bs, n - 1),
    ]));
    hessenberg::hessenberg_in_place(a.as_mut(), coeff.as_mut(), Par::Seq, MemStack::new(&mut mem), Default::default());
    for j in 0..n { for i in j + 2..n { a[(i, j)] = 0.0; } }
    a
}
fn median(mut v: Vec<f64>) -> f64 { v.sort_by(|a,b|a.partial_cmp(b).unwrap()); v[v.len()/2] }

fn main() {
    if let Ok(nn)=std::env::var("ONLY_N"){let n:usize=nn.parse().unwrap();let h=hess(n,12345);let mut mem=MemBuffer::new(hessenberg_schur_scratch::<f64>(n,true,Par::Seq.shape(),Default::default()));for _ in 0..std::env::var("LOOPS").ok().and_then(|s|s.parse().ok()).unwrap_or(3000){let mut a=h.clone();let mut re=Col::<f64>::zeros(n);let mut im=Col::<f64>::zeros(n);hessenberg_schur_real(a.as_mut(),None,re.as_mut(),im.as_mut(),Par::Seq,MemStack::new(&mut mem),Default::default()).unwrap();}return;}
    if let Ok(nn)=std::env::var("ONLY_OB"){let n:usize=nn.parse().unwrap();let h=hess(n,12345);
      for _ in 0..std::env::var("LOOPS").ok().and_then(|s|s.parse().ok()).unwrap_or(3000){
        let mut hh: Vec<f64> = (0..n*n).map(|x| h[(x % n, x / n)]).collect();
        let mut wr = vec![0.0; n]; let mut wi = vec![0.0; n];
        let ni = n as i32; let one = 1i32; let mut info = 0i32; let lw=(n as i32)*4; let mut work=vec![0.0;lw as usize]; let mut z=[0.0f64];
        unsafe { dhseqr_(b"E".as_ptr(), b"N".as_ptr(), &ni,&one,&ni,hh.as_mut_ptr(),&ni,wr.as_mut_ptr(),wi.as_mut_ptr(),z.as_mut_ptr(),&one,work.as_mut_ptr(),&lw,&mut info); }
      } return; }
    if std::env::var("HASH").is_ok(){
      for &n in &[5usize,16,33,64,75,97,128]{ for seed in 0..4u64 {
        let h=hess(n,0x2545F4914F6CDD1Du64^(seed*0x9E3779B97F4A7C15));
        let mut mem=MemBuffer::new(hessenberg_schur_scratch::<f64>(n,true,Par::Seq.shape(),Default::default()));
        let mut a=h.clone();let mut q=Mat::<f64>::identity(n,n);let mut re=Col::<f64>::zeros(n);let mut im=Col::<f64>::zeros(n);
        hessenberg_schur_real(a.as_mut(),Some(q.as_mut()),re.as_mut(),im.as_mut(),Par::Seq,MemStack::new(&mut mem),Default::default()).unwrap();
        let mut hs:u64=0xcbf29ce484222325;
        let mut f=|x:f64|{hs^=x.to_bits();hs=hs.wrapping_mul(0x100000001b3);};
        for j in 0..n{for i in 0..n{f(a[(i,j)]);f(q[(i,j)]);}f(re[j]);f(im[j]);}
        println!("n={n} seed={seed} {hs:016x}");
      }} return; }
    let reps: usize = std::env::args().nth(1).map(|s| s.parse().unwrap()).unwrap_or(101);
    println!("reps={reps} (median of per-call us; 8 distinct matrices cycled)");
    println!("{:>4} {:>12} {:>12} {:>12} {:>7}", "n", "colmat_E", "colmat_Z", "openblas_E", "ratio_E");
    for &n in &[16usize, 32, 48, 64, 96, 128] {
        let hs: Vec<Mat<f64>> = (0..8).map(|k| hess(n, 0x2545F4914F6CDD1Du64 ^ (k as u64 * 0x9E3779B97F4A7C15))).collect();
        let mut mem = MemBuffer::new(hessenberg_schur_scratch::<f64>(n, true, Par::Seq.shape(), Default::default()));
        let mut run = |want_z: bool, k: usize| -> f64 {
            let mut a = hs[k % 8].clone();
            let mut q = Mat::<f64>::identity(n, n);
            let mut re = Col::<f64>::zeros(n); let mut im = Col::<f64>::zeros(n);
            let t = Instant::now();
            hessenberg_schur_real(a.as_mut(), if want_z {Some(q.as_mut())} else {None}, re.as_mut(), im.as_mut(), Par::Seq, MemStack::new(&mut mem), Default::default()).unwrap();
            t.elapsed().as_secs_f64() * 1e6
        };
        for k in 0..8 { run(false, k); run(true, k); }
        let ce: Vec<f64> = (0..reps).map(|k| run(false, k)).collect();
        let cz: Vec<f64> = (0..reps).map(|k| run(true, k)).collect();
        let ob = |k: usize| -> f64 {
            let mut h: Vec<f64> = (0..n*n).map(|x| hs[k%8][(x % n, x / n)]).collect();
            let mut wr = vec![0.0; n]; let mut wi = vec![0.0; n];
            let ni = n as i32; let one = 1i32; let mut info = 0i32;
            let mut lw = -1i32; let mut wq = [0.0f64];
            let mut z = [0.0f64];
            unsafe { dhseqr_(b"E".as_ptr(), b"N".as_ptr(), &ni,&one,&ni,h.as_mut_ptr(),&ni,wr.as_mut_ptr(),wi.as_mut_ptr(),z.as_mut_ptr(),&one,wq.as_mut_ptr(),&lw,&mut info); }
            lw = wq[0] as i32; let mut work = vec![0.0; lw as usize];
            let t = Instant::now();
            unsafe { dhseqr_(b"E".as_ptr(), b"N".as_ptr(), &ni,&one,&ni,h.as_mut_ptr(),&ni,wr.as_mut_ptr(),wi.as_mut_ptr(),z.as_mut_ptr(),&one,work.as_mut_ptr(),&lw,&mut info); }
            assert_eq!(info, 0);
            t.elapsed().as_secs_f64() * 1e6
        };
        for k in 0..8 { ob(k); }
        let oe: Vec<f64> = (0..reps).map(|k| ob(k)).collect();
        let (c, o) = (median(ce), median(oe));
        println!("{:>4} {:>12.1} {:>12.1} {:>12.1} {:>7.2}", n, c, median(cz), o, c / o);
    }
}
