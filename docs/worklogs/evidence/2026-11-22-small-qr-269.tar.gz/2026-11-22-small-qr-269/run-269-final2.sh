#!/bin/bash
cd ~/projects/tensor4all/colmat-benchmark-95
./ab-269.sh FA linalg-small qr_factor,qr 32,48,64,96,128,160,192 f64 1 4 8 > /dev/null 2>&1
./ab-269.sh FB linalg-small qr_factor,qr 32,64,96,128 c64,f32,c32 1 4 8 > /dev/null 2>&1
./ab-269.sh FC linalg-small svd_thin,svd_values,eigh,solve,householder_apply,lu,cholesky 16,24,32,48 f64,c64 1 8 > /dev/null 2>&1
./ab-269.sh FD linalg-large qr_factor,qr 256,512,1024 f64 4 8 > /dev/null 2>&1
./ab-269.sh FD1 linalg-large qr_factor,qr 256,512 f64 1 > /dev/null 2>&1
echo FINAL2-DONE
