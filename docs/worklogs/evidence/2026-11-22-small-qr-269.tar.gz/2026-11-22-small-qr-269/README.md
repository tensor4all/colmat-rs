# colmat-rs#269 evidence

Paired A/B on evo (AMD Ryzen AI 9 HX 470, boost off, 2.0 GHz), fbench from colmat-benchmark
`6dcefea` (AOCL arm, AOCL 6.0.0 LP64 MT), measured CPUs 4 (1T), 4-7 (4T), 4-11 (8T), observer
on 0-3,12-15. `base` = colmat `origin/main` 33d34668, `cand` = 7b3f5b4e (this PR's code commit).
`--reps 5 --prime-ms 250 --statistic median --rotate-rows 1`, one process per thread count.

- `raw/ab-<set>-<arm>-<T>.csv`: fbench rows; `samples_ms` holds the five reps.
- `tab-*.md`: median [Q1, Q3] per call in us (`summarize.py`), F-order rows.
- Sets: FA f64 qr_factor/qr 32..192 1/4/8T; FB c64/f32/c32; FC collateral families 16..48;
  FD/FD1 large n (256..1024); R1/R2 collateral repeats with the arm order reversed
  (cand first); H householder_apply, Bc complex on teams, Dr large 8T reversed: checks after the
  team gates were added (same code as 7b3f5b4e).
