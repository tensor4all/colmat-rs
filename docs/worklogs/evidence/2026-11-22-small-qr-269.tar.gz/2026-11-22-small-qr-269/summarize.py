import csv, json, sys, statistics as st

D = "/tmp/claude-1000/-tmp/f812e8ca-903e-4682-b86a-3d21d54d3eff/scratchpad/ab"


def q(xs, p):
    xs = sorted(xs)
    k = (len(xs) - 1) * p
    lo = int(k)
    hi = min(lo + 1, len(xs) - 1)
    return xs[lo] + (xs[hi] - xs[lo]) * (k - lo)


def load(label, arm, T):
    out = {}
    for r in csv.DictReader(open(f"{D}/ab-{label}-{arm}-{T}.csv")):
        if r["status"] != "ok" or r["row"] not in ("faer-fork", "lapack-aocl"):
            continue
        if r["order"] != "f":
            continue
        s = [float(x) * 1000.0 / int(r["batch"]) for x in json.loads(r["samples_ms"])]
        shape = f"{r['m']}x{r['n']}" if r["m"] != r["n"] else f"{r['m']}"
        fam = r["family"] + (" (api)" if r["note"] == "api-inclusive" else "")
        key = (fam, r["dtype"], shape, r["row"])
        out[key] = (st.median(s), q(s, 0.25), q(s, 0.75))
    return out


def fmt(t):
    m, a, b = t
    return f"{m:.2f} [{a:.2f}, {b:.2f}]" if m < 100 else f"{m:.1f} [{a:.1f}, {b:.1f}]"


label = sys.argv[1]
threads = sys.argv[2].split(",")
for T in threads:
    b, c = load(label, "base", T), load(label, "cand", T)
    print(f"\n**{T}T** (us per call, median [Q1, Q3] of 5)\n")
    print("| family | dtype | n | before | after | after/before | AOCL | after/AOCL |")
    print("|---|---|---|---|---|---|---|---|")
    keys = sorted({k[:3] for k in b if k[3] == "faer-fork"},
                  key=lambda k: (k[0], k[1], int(k[2].split("x")[0]) * 10000 + int(k[2].split("x")[-1])))
    for k in keys:
        kb, kc = b.get(k + ("faer-fork",)), c.get(k + ("faer-fork",))
        if not kb or not kc:
            continue
        ka = b.get((k[0].replace(" (api)", ""), k[1], k[2], "lapack-aocl"))
        aocl = fmt(ka) if ka else "-"
        ra = f"{kc[0] / ka[0]:.2f}" if ka else "-"
        print(f"| {k[0]} | {k[1]} | {k[2]} | {fmt(kb)} | {fmt(kc)} | {kc[0] / kb[0]:.2f} | {aocl} | {ra} |")
