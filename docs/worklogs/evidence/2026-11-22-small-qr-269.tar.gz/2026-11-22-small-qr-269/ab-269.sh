#!/bin/bash
# A/B a family group between the baseline worktree binary and the candidate one.
# Usage: ab-262.sh <label> <regime> <families-comma> <shapes> <dtypes> [threads...]
set -u
cd "$(dirname "$0")"
export AOCL_ROOT=$(scripts/resolve_aocl_root.sh)
export LD_LIBRARY_PATH=$AOCL_ROOT/lib_LP64
label=$1; regime=$2; fams=$3; shapes=$4; dtypes=$5; shift 5
threads=${*:-4 8}
for arm in ${ARMS:-base cand}; do
  case $arm in base) B=$PWD/target/loop-269-base/release/fbench;; cand) B=$PWD/target/loop-269-cand/release/fbench;; esac
  for T in $threads; do
    case $T in 1) C=4;; 2) C=4-5;; 4) C=4-7;; 8) C=4-11;; esac
    out=/tmp/claude-1000/-tmp/f812e8ca-903e-4682-b86a-3d21d54d3eff/scratchpad/ab/ab-$label-$arm-$T.csv
    PINNED_CSV=$out benchmarks/scripts/pinned.sh $C -- \
      $B run --threads $T --n $shapes --family $fams --regime $regime \
        --dtype $dtypes --reps 5 --prime-ms 250 --statistic median --rotate-rows 1 \
        --csv $out > /tmp/claude-1000/-tmp/f812e8ca-903e-4682-b86a-3d21d54d3eff/scratchpad/ab/ab-last.log 2>&1 || { echo "ARM $arm ${T}T FAILED"; tail -4 /tmp/claude-1000/-tmp/f812e8ca-903e-4682-b86a-3d21d54d3eff/scratchpad/ab/ab-last.log; }
  done
done
python3 - "$label" "$threads" <<'PY'
import csv, sys
label, threads = sys.argv[1], sys.argv[2].split()
for T in threads:
    base = {r['case']: r for r in []}
    def load(arm):
        d = {}
        for r in csv.DictReader(open(f"/tmp/claude-1000/-tmp/f812e8ca-903e-4682-b86a-3d21d54d3eff/scratchpad/ab/ab-{label}-{arm}-{T}.csv")):
            if r['status'] != 'ok' or r['row'] != 'faer-fork':
                continue
            key = f"{r['family']}/{r['m']}x{r['k']}x{r['n']}/{r['order']}/{r['dtype']}"
            d[key] = float(r['per_item_us'])
        return d
    b, c = load('base'), load('cand')
    aocl = {}
    for r in csv.DictReader(open(f"/tmp/claude-1000/-tmp/f812e8ca-903e-4682-b86a-3d21d54d3eff/scratchpad/ab/ab-{label}-base-{T}.csv")):
        if r['status'] == 'ok' and r['row'] == 'lapack-aocl':
            key = f"{r['family']}/{r['m']}x{r['k']}x{r['n']}/{r['order']}/{r['dtype']}"
            aocl[key] = float(r['per_item_us'])
    print(f"== {label} {T}T   case                          base      cand    cand/base   cand/aocl")
    for k in sorted(set(b) & set(c)):
        ratio = c[k] / b[k] if b[k] else 0
        ra = c[k] / aocl[k] if aocl.get(k) else 0
        print(f"   {k:<40} {b[k]:9.3f} {c[k]:9.3f}   {ratio:7.2f}    {ra:7.2f}")
PY
